<?php return array (
  'footer' => 'App\\Http\\Livewire\\Footer',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
  'navigation-bottom' => 'App\\Http\\Livewire\\NavigationBottom',
);