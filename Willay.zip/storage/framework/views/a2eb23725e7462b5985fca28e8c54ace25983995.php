<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-8">
        <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="mb-8 bg-white shadow-lg rounded-lg overflow-hidden
                    <?php if($loop->first): ?> md:col-span-2
                    <?php endif; ?>">
                    <img class="w-full h-72 object-center object-cover" src="<?php echo e(Storage::url($report->image->url)); ?>" alt="">
                    
                    <div class="px-6 py-4">
                        <h1 class="text-2xl text-gray-400 leading-8 font-bold hover:text-gray-500 mb-2">
                            <a href="<?php echo e(route('reports.show', $report)); ?>"><?php echo e($report->name); ?></a>
                        </h1>
                        <div class="text-gray-700 text-base">
                            <?php echo e($report->extract); ?>

                        </div>
                    </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="mt-4">
            <?php echo e($reports->links()); ?>

        </div>

    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Willay\resources\views/reports/index.blade.php ENDPATH**/ ?>