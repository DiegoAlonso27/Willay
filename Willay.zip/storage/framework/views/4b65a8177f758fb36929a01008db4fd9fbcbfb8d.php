<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <article class="mb-8 bg-white shadow-lg rounded-lg overflow-hidden md:col-span-2">
                <?php if (isset($component)) { $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardView::class, ['categoria' => 'CRÓNICAS','titulo' => 'SOLIDARIDAD Y ENSEÑANZA QUE MEJORAN LA EDUCACIÓN','link' => ''.e(route('posts.show')).'','img' => '/img/unnamed.jpg','content' => 'La pandemia provocada por el COVID-19 no solo afecto y perjudicó a personas mayores con el desempleo, sino que también a la educación de muchos niños con bajos recursos, que no contaban con Wifi en casa, un televisor, una laptop o siquiera con un teléfono digital, implementos indispensables para continuar con su educación en casa...']); ?>
<?php $component->withName('card-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721)): ?>
<?php $component = $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721; ?>
<?php unset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </article>
            <article class="mb-8 bg-white shadow-lg rounded-lg overflow-hidden col-span-1">
                <?php if (isset($component)) { $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardView::class, ['categoria' => 'CRÓNICAS','titulo' => 'Planetastico, un libro que desarrolla conciencia ambiental','link' => ''.e(route('posts.show2')).'','img' => '/img/conciencia-ambienta-823x400.jpg','content' => 'Aldrish Galvez, es un chiclayano de 18 años, creador de un libro llamado Planetastico, el cual cuenta con un tema muy importante hoy en día, el cuidado del medio ambiente. Para la realización del libro decidió basarse en su propia experiencia de vida, la cual utilizó tanto para la historia como para la realización de los personajes...']); ?>
<?php $component->withName('card-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721)): ?>
<?php $component = $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721; ?>
<?php unset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </article>
            <article class="mb-8 bg-white shadow-lg rounded-lg overflow-hidden col-span-1">
                <?php if (isset($component)) { $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardView::class, ['categoria' => 'CRÓNICAS','titulo' => 'CORDELIA SÁNCHEZ, UNA VOZ QUE PIDE INFORMACIÓN PARA TODOS','link' => ''.e(route('posts.show3')).'','img' => '/img/microfono_0.jpg','content' => 'La señora Cordelia pide igualdad en los medios.
                    Era un martes como cualquiera, y como todos los martes me despertaba temprano a realizar los quehaceres del día, sin embargo, este día iba ser diferente. Me terminaba de alistar y sin tomar desayuno corrí a tomar el micro que me llevaría a Canto Grande camino a la vivienda de la señora Cordelia Sánchez. Por otra ruta me daba el alcance mi...']); ?>
<?php $component->withName('card-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721)): ?>
<?php $component = $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721; ?>
<?php unset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </article>
        </div>

        

    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Willay\resources\views/posts/index.blade.php ENDPATH**/ ?>