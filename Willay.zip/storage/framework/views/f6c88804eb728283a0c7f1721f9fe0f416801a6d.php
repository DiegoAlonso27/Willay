<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-8">
        <h1 class="text-4xl fond-bold text-gray-600"><?php echo e($report->name); ?></h1>

        <div class="text.lg text-gray-500 mb-2">
            <?php echo e($report->extract); ?>

        </div>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <div class="lg:col-span-2">

                <figure>
                    <img src="<?php echo e(Storage::url($report->image->url)); ?>" class="w-full h-80 object-cover object-center"
                        alt="">
                </figure>
                <div class="text-base text-gray-500 mt-4">
                    <?php echo e($report->body); ?>

                </div>

            </div>
            
            <aside>
                <h1 class="text-2xl font-bold text-gray-600">
                    Mas en <?php echo e($report->category->name); ?>

                </h1>
                <ul>
                    <?php $__currentLoopData = $similares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-4">
                            <a class="flex" href="<?php echo e(route('reports.show', $similar)); ?>">
                                <img class="w-36 h-20 object-cover object-center"
                                    src="<?php echo e(Storage::url($similar->image->url)); ?>" alt="">
                                <span class="w-52 ml-2 text-gray-600"><?php echo e($similar->name); ?></span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </aside>

        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Willay\resources\views/reports/show.blade.php ENDPATH**/ ?>