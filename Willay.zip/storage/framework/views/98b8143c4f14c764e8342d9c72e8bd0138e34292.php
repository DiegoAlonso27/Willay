<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slider::class, []); ?>
<?php $component->withName('slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee)): ?>
<?php $component = $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee; ?>
<?php unset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    
    <div class="container py-4">
        <div class="mb-10 mt-8">
            <a role="button" class=" text-xl bg-red-600 hover:bg-red-700 text-white px-8 py-4  border rounded-full">
                Novedades
            </a>
        </div>
        <div class="my-4">
            <div class="md:flex mt-8 md:-mx-4">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php if (isset($component)) { $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ViewCard::class, ['titulo' => 'SOLIDARIDAD Y ENSEÑANZA QUE MEJORAN LA EDUCACIÓN','link' => ''.e(route('posts.show')).'','img' => '/img/unnamed.jpg']); ?>
<?php $component->withName('view-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943)): ?>
<?php $component = $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943; ?>
<?php unset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ViewCard::class, ['titulo' => 'Planetastico, un libro que desarrolla conciencia ambiental','link' => ''.e(route('posts.show2')).'','img' => '/img/conciencia-ambienta-823x400.jpg']); ?>
<?php $component->withName('view-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943)): ?>
<?php $component = $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943; ?>
<?php unset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ViewCard::class, ['titulo' => 'CORDELIA SÁNCHEZ, UNA VOZ QUE PIDE INFORMACIÓN PARA TODOS','link' => ''.e(route('posts.show3')).'','img' => '/img/microfono_0.jpg']); ?>
<?php $component->withName('view-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943)): ?>
<?php $component = $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943; ?>
<?php unset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="flex justify-center border-t-2 border-b-2 border-red-600 py-2 mb-8 mx-auto">
        <a class="font-bold text-black text-base hover:text-gray-600 md:text-xl lg:text-2xl"
            href="<?php echo e(route('posts.index')); ?>">VER MÁS</a>
    </div>
    <div class="bg-gray-500">
        <div class="container py-4 ">
            <form class="w-full  px-8 pt-6 pb-4 mb-2">
                <div class="mb-4">
                    <input
                        class="shadow appearance-none border rounded w-full p-3 text-gray-700 leading-tight focus:ring transform transition hover:scale-105 duration-300 ease-in-out"
                        id="emailaddress" type="email" placeholder="ejemplo@email.com">
                </div>

                <div class="flex items-center justify-between pt-4">
                    <button
                        class="text-xl bg-gradient-to-r from-red-700 to-red-300 hover:from-red-900 hover:to-red-400 text-white font-bold py-2 px-4 rounded focus:ring transform transition hover:scale-105 duration-300 ease-in-out"
                        type="submit">
                        RECIBIR NOTICIAS
                    </button>
                </div>
            </form>
        </div>
    </div>
    <div class="container py-4">
        <div class="mb-10 mt-8">
            <a role="button" class=" text-xl bg-red-600 hover:bg-red-700 text-white px-8 py-4  border rounded-full">
                YOUTUBE
            </a>
        </div>
        <div class="my-4">
            <div class="md:flex mt-8 md:-mx-4">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php if (isset($component)) { $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ViewCard::class, ['titulo' => 'Podcast Aldrish Gálvez, creador del Libro Planetastico','link' => '#','img' => '/img/PODCAST ALDRISH GÁLVEZ.jpg']); ?>
<?php $component->withName('view-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943)): ?>
<?php $component = $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943; ?>
<?php unset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ViewCard::class, ['titulo' => 'Entrevista a Sadhami, voluntaria de la Enséñame','link' => ''.e(route('interviews.show2')).'','img' => '/img/ENTREVISTA SADHAMI CARAZA.jpg']); ?>
<?php $component->withName('view-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943)): ?>
<?php $component = $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943; ?>
<?php unset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ViewCard::class, ['titulo' => 'Entrevista a Roxana Quispe Collantes','link' => ''.e(route('interviews.show')).'','img' => '/img/ENTREVISTA A ROXANA QUISPE COLLANTES.jpg']); ?>
<?php $component->withName('view-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943)): ?>
<?php $component = $__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943; ?>
<?php unset($__componentOriginalf2206628f90073c903ab1682d1af8bf69ce90943); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
        <div class="mb-4 mt-8">
            <a role="button" href="https://www.youtube.com/channel/UC5S3pJ0DgcbJv0ezM2erXxA/videos" target="_blank"
                class="flex justify-center m-auto text-xl bg-red-600 hover:bg-red-700 text-white px-8 py-4  border rounded-full">
                VISITA NUESTRO CANAL
            </a>
        </div>
    </div>
    <div class="container pb-8">
        <div class="mb-10 mt-4">
            <a role="button" class=" text-xl bg-red-600 hover:bg-red-700 text-white px-8 py-4  border rounded-full">
                COMIC DEL MES
            </a>
        </div>
        <div class="w-full h-32 md:h-56 lg:h-80">
            <img class="w-full h-full md:mx-4 rounded-md overflow-hidden object-cover object-center bg-gray-500 shadow appearance-none leading-tight focus:ring transform transition hover:scale-105 duration-300 ease-in-out flex items-center mt-4 text-sm uppercase font-medium hover:underline focus:outline-none" src="/img/comic-min.jpg" alt="">
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Willay\resources\views/home/index.blade.php ENDPATH**/ ?>