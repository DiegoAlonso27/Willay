<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container py-8">
        <h1 class="text-4xl fond-bold text-gray-600">HOLA WILLAY PODCAST - EDICIÓN 01</h1>

        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <div class="lg:col-span-2">

                <b class="text-xl">Autor: Ordoñez Odar, Josep Garip</b></br>
                <figure>
                    <iframe class="w-full h-80 object-cover object-center my-6 rounded-md"
                        src="https://www.youtube.com/embed/pFbYClTFbk8" title="YouTube video player" frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen></iframe>
                </figure>
            </div>
            
            <aside>
                <h1 class="text-2xl font-bold text-gray-600 my-6">
                    Más en Entrevistas
                </h1>
                <ul>
                    <li class="mb-4">
                        <a class="flex" href="<?php echo e(route('podcasts.show')); ?>">
                            <img class="w-36 h-20 object-cover object-center rounded-md"
                                src="/img/PODCAST ALDRISH GÁLVEZ.jpg" alt="">
                            <span class="w-52 ml-2 text-gray-600">Podcast Aldrish Gálvez, creador del Libro Planetastico</span>
                        </a>
                    </li>
                    <li class="mb-4">
                        <a class="flex" href="<?php echo e(route('podcasts.show3')); ?>">
                            <img class="w-36 h-20 object-cover object-center rounded-md"
                                src="/img/PODCAST PAÚL RIVERA.jpg" alt="">
                            <span class="w-52 ml-2 text-gray-600">HOLA WILLAY PODCAST - EDICIÓN 02</span>
                        </a>
                    </li>
                </ul>
            </aside>

        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Willay\resources\views/podcasts/show2.blade.php ENDPATH**/ ?>