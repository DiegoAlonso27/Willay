<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <article class="mb-8 bg-white shadow-lg rounded-lg overflow-hidden md:col-span-2">
                <?php if (isset($component)) { $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardView::class, ['categoria' => 'CASOS','titulo' => 'Entrevista a Roxana Quispe Collantes','link' => ''.e(route('interviews.show')).'','img' => '/img/ENTREVISTA A ROXANA QUISPE COLLANTES.jpg','content' => '']); ?>
<?php $component->withName('card-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721)): ?>
<?php $component = $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721; ?>
<?php unset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </article>
            <article class="mb-8 bg-white shadow-lg rounded-lg overflow-hidden col-span-1">
                <?php if (isset($component)) { $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardView::class, ['categoria' => 'ESPECIALISTAS','titulo' => 'Entrevista a Sadhami, voluntaria de la Enséñame','link' => ''.e(route('interviews.show2')).'','img' => '/img/ENTREVISTA SADHAMI CARAZA.jpg','content' => '']); ?>
<?php $component->withName('card-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721)): ?>
<?php $component = $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721; ?>
<?php unset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </article>
            <article class="mb-8 bg-white shadow-lg rounded-lg overflow-hidden col-span-1">
                <?php if (isset($component)) { $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardView::class, ['categoria' => 'CASOS','titulo' => 'Entrevista a Beatriz García Blasco','link' => ''.e(route('interviews.show3')).'','img' => '/img/ENTREVISTA BEATRIZ GARCÍA BLASCO.jpg','content' => '']); ?>
<?php $component->withName('card-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721)): ?>
<?php $component = $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721; ?>
<?php unset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </article>
            <article class="mb-8 bg-white shadow-lg rounded-lg overflow-hidden col-span-1">
                <?php if (isset($component)) { $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardView::class, ['categoria' => 'ESPECIALISTAS','titulo' => 'Entrevista a Alvin Medina','link' => ''.e(route('interviews.show4')).'','img' => '/img/ENTREVISTA A ALVIN MEDINA.jpg','content' => '']); ?>
<?php $component->withName('card-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721)): ?>
<?php $component = $__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721; ?>
<?php unset($__componentOriginalad2d51ec7b1401018050bbb9fd5c21bf2c6d1721); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </article>
        </div>

        

    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Willay\resources\views/interviews/index.blade.php ENDPATH**/ ?>