<a href="/">
    <img class="block lg:hidden h-24 w-auto" src="/img/logo-4.svg" alt="Workflow">
    <img class="hidden lg:block h-28 w-auto" src="/img/logo-3.svg" alt="Workflow">
    
</a>
<?php /**PATH C:\xampp\htdocs\Willay\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>